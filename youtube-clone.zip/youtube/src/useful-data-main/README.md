# RIT-Explorin

const DBURI = "mongodb+srv://youtubeclone:1234@cluster0.5ofd4si.mongodb.net/youtubeclone_YOURROLLNUMBER"
